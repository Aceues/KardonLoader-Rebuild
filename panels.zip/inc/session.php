    <?php
    session_start();
    if( !isset($_SESSION['Kardon']) ) 
    {
        header("Location: ../index.php");
        exit;
    }
    $u = explode(":", $_SESSION['Kardon']);
    $username = $u[0];
    ?>